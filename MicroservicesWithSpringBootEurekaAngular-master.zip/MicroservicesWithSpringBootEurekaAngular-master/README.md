A Elegant project using JAVA, Spring Boot, MVC, REST Api, Microservices with Spring Boot and Eureka, Spring Cloud and Maven.

Thanks!
