package com.watchMyStockPrice.dbService.repository;

import com.watchMyStockPrice.dbService.model.Quote;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuotesRepository extends JpaRepository<Quote, Integer> {
    List<Quote> findByUserName(String username);

}
