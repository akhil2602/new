package com.watchMyStockPrice.dbService.resource;


import com.watchMyStockPrice.dbService.model.Quote;
import com.watchMyStockPrice.dbService.model.Quotes;
import com.watchMyStockPrice.dbService.repository.QuotesRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/db")
public class DbServiceResource {

    private QuotesRepository quotesreposity;

    public DbServiceResource(QuotesRepository quotesReposity) {
        this.quotesreposity = quotesReposity;
    }


    @GetMapping("/{username}")
    public List<String> getQuotes(@PathVariable("username") final String username) {

        return getQuotesByUserName(username);
    }

    @PostMapping("/add")
    public List<String> add(@RequestBody final Quotes quotes) {
        quotes.getQuotes()
                .stream()
                .map(quote -> new Quote(quotes.getUsername(), quote))
                .forEach(quote -> quotesreposity.save(quote));
        return getQuotesByUserName(quotes.getUsername());
    }

    @PostMapping("/delete/{username}")
    public List<String> delete(@PathVariable("username") final String username) {

        List<Quote> quotes = quotesreposity.findByUserName(username);

        quotesreposity.deleteAll(quotes);

        return getQuotesByUserName(username);
    }

    private List<String> getQuotesByUserName(@PathVariable("username") String username) {
        return quotesreposity.findByUserName(username)
                .stream()
                .map(Quote::getQuote)
                .collect(Collectors.toList());
    }

}
